/**
 * 示例页面二
 */
import React, { Component } from 'react'

import { connect } from 'react-redux'

class Admin extends Component {
  render() {
    return <div>111</div>
  }
}
export default connect((state) => ({ user: state.user }), {})(Admin)
