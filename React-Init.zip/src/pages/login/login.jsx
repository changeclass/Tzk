import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Redirect } from 'react-router-dom'

import { setHeadTitle } from '../../redux/actions'

/**
 * 示例页面一
 */

class Login extends Component {
  render() {
    const { user, title } = this.props

    console.log(user, title)
    this.props.setHeadTitle('666')
    return <div className='login'>登录{this.props.title}</div>
  }
}
export default connect(
  (state) => ({ user: state.user, title: state.headTitle }),
  { setHeadTitle }
)(Login)
